#!/bin/bash
module load raxml
raxmlHPC -m GTRGAMMA -p $RANDOM -b $RANDOM -# 1 -s 16S18S28SCOI_Cap.phy -q 16S18S28SCOI_Cap_Partitions.txt -n boot_$1
