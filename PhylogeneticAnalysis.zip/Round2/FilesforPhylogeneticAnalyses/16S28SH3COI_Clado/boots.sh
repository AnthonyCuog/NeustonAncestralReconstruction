#!/bin/bash
module load raxml
raxmlHPC -m GTRGAMMA -p $RANDOM -b $RANDOM -# 1 -s 16S28SH3COI_Clado.phy -q 16S28SH3COI_Clado_Partitions.txt -n boot_$1
