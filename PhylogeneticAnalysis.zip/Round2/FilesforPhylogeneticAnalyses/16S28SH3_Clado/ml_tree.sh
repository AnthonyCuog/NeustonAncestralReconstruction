#!/bin/bash
module load raxml
raxmlHPC -m GTRGAMMA -p $RANDOM -# 10 -s 16S28SH3_Clado.phy -q 16S28SH3_Clado_Partitions.txt -n BestTree
