#!/bin/bash
module load raxml
raxmlHPC -m GTRGAMMA -p $RANDOM -# 10 -s 16S28SH3_Epi.phy -q 16S28SH3_Epi_Partitions.txt -n BestTree
