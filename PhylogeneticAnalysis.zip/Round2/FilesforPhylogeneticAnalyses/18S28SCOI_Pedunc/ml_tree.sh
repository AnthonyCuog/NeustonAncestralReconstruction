#!/bin/bash
module load raxml
raxmlHPC -m GTRGAMMA -p $RANDOM -# 10 -s 18S28SCOI_Pedunc.phy -q 18S28SCOI_Pedunc_Partitions.txt -n BestTree
