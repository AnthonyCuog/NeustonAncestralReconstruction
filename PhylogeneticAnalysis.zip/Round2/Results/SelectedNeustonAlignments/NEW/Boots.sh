for i in *_* ; do cd $i ; cat  RAxML_bootstrap.* > BootstrapTrees.tre && cd .. ; done
