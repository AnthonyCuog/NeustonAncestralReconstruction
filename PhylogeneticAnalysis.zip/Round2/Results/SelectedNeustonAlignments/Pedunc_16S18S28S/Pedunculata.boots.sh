#!/bin/bash
module load raxml
raxmlHPC -m GTRGAMMA -p $RANDOM -b $RANDOM -# 1 -s 16S18S28S_Pedunc.phy -q 16S18S28S_Pedunc_Partitions.txt -n Pedunc_$1
