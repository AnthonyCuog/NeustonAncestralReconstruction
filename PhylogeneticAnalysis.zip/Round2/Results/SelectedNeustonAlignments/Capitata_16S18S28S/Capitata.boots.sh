#!/bin/bash
module load raxml
raxmlHPC -m GTRGAMMA -p $RANDOM -b $RANDOM -# 1 -s 16S18S28S_Cap.phy -q 16S18S28S_Cap_Partitions.txt -n Capitata_$1
