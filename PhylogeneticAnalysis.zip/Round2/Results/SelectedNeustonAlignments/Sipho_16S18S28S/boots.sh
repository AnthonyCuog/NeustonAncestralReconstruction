#!/bin/bash
module load raxml
raxmlHPC -m GTRGAMMA -p $RANDOM -b $RANDOM -# 1 -s 16S18S28S_Sipho.phy -q 16S18S28S_Sipho_Partitions.txt -n boot_$1
